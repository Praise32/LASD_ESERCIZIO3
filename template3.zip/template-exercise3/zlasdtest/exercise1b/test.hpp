
#ifndef EX1BTEST_HPP
#define EX1BTEST_HPP

/* ************************************************************************** */

void testSimpleExercise1B(unsigned int &, unsigned int &);

void testFullExercise1B(unsigned int &, unsigned int &);

/* ************************************************************************** */

#endif
