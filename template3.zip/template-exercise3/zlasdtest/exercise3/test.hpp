
#ifndef EX3TEST_HPP
#define EX3TEST_HPP

/* ************************************************************************** */

void testSimpleExercise3(unsigned int &, unsigned int &);

void testFullExercise3(unsigned int &, unsigned int &);

/* ************************************************************************** */

#endif
